## Source Code Information
By the developers of bottodir.
Last update: 2/13/2022, v6.

## General Information
The source code (curr. lt. v. v6) is running on Node v16.
By modifying the source, you will lose the lifetime support.

## Security
To avoid bugs and keep 100% security, do not modify anything within the repo and database.
Environment keys, tokens and ids should stay in the .env / config files.
Keys should be encrypted and stay within a save Database.
