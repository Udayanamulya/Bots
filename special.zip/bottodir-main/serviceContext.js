require('@google-cloud/profiler').start({
    serviceContext: {
      service: 'Bottodir',
      version: '2.5.0',
    },
  })
