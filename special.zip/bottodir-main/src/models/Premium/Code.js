
/*
const { Schema, Types, model } = require("mongoose");

// Generate Premium Code
const premiumCode = Schema({
  code: 
  {
    type: String,
    default: null
  },

  // Set the expire date and time. <Day, Week, Month, Year>
  expiresAt: 
  {
    type: Number,
    default: null
  },

  // Set the plan <Day, Week, Month>.
  plan: 
  {
    type: String,
    default: null
  }
})

const Code = model("Code", premiumCode)

module.exports = Code;
*/