module.exports = {
    apps: [
        {
            name: "Bottodir",
            script: ".", 
            version: "v5.5.0",
            autorestart: true,
            watch: false,
        },
    ],
};
